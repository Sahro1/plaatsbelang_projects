<template>
  <div class="advertentie">
    <h1>Adress info: Winkel straat</h1>

    <div id="app">
      <input type="text" placeholder="Search..">
      
      <input type="text" v-model="location" placeholder=" Groningen "></input>
      <input type="text" v-model="Adresss" placeholder="Westerhaven 20"></input>
    
      <input type="text" v-model="format" placeholder=" :"></input>
      

    </div>
    <br>
    <div class="card">
  
  <div class="card-body">
     <h5 class="card-title">Schoenen</h5>
    <img src="/src/assets/img/th.jpeg" alt="Italian Trulli">
   
    <p class="card-text">Alle beste schoenen.</p>
    <a href="#" class="btn btn-primary"></a>
  </div>
</div>
    
   
  </div>
</template>

<style>
@media (min-width: 1024px) {
  . {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}

.app input .[type=text]{
  float: right;
  padding: 6px;
  border: none;
  margin-top: 8px;
  margin-right: 16px;
  font-size: 17px
}



</style>
