<script setup>

</script>

<template>
  <WelcomeItem>
    <template #icon>
      <DocumentationIcon />
    </template>
   

  

  
   
  </WelcomeItem>
  
</template>
